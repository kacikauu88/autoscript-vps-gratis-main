#!/bin/bash
# ==========================================
# ==========================================
# 
cd

cd /usr/bin


wget -O fb-addgrpc "https://raw.github.com/kacikauu88/server-ssh-yuri/main/grpc/fb-addgrpc.sh"
wget -O fb-delgrpc "https://raw.github.com/kacikauu88/server-ssh-yuri/main/grpc/fb-delgrpc.sh"
wget -O fb-renewgrpc "https://raw.github.com/kacikauu88/server-ssh-yuri/main/grpc/fb-renewgrpc.sh"
wget -O fb-cekgrpc "https://raw.github.com/kacikauu88/server-ssh-yuri/main/grpc/fb-cekgrpc.sh"

chmod +x fb-addgrpc
chmod +x fb-delgrpc
chmod +x fb-renewgrpc
chmod +x fb-cekgrpc

cd
