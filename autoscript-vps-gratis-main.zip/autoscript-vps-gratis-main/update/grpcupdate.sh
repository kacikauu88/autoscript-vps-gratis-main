#!/bin/bash
# ==========================================
# ==========================================
# 
cd

cd /usr/bin

wget -O addgrpc "https://raw.github.com/kacikauu88/server-ssh-yuri/main/xray/addgrpc.sh"
wget -O cekgrpc "https://raw.github.com/kacikauu88/server-ssh-yuri/main/xray/cekgrpc.sh"
wget -O delgrpc "https://raw.github.com/kacikauu88/server-ssh-yuri/main/xray/delgrpc.sh"
wget -O renewgrpc "https://raw.github.com/kacikauu88/server-ssh-yuri/main/xray/renewgrpc.sh"


chmod +x addgrpc
chmod +x delgrpc
chmod +x cekgrpc
chmod +x renewgrpc

cd
