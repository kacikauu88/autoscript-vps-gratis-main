#!/bin/bash

cd
sudo apt update -y
apt update -y
sudo apt install git -y
apt install git -y
cd
cd /root/
git clone https://github.com/fisabiliyusri/Mantap

cd
